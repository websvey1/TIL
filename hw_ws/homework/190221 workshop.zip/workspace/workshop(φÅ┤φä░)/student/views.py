from django.shortcuts import render, redirect
from .models import Student
# Create your views here.
def index(request):
    # student = Student.objects.all()
    student = Student.objects.order_by('-id')
    return render(request, 'student/index.html', {'student':student})

def new(request):
    return render(request, 'student/new.html')

def create(request):
    name = request.POST.get('name')
    email = request.POST.get('email')
    birthdat = request.POST.get('birthdat')
    age = request.POST.get('age')
    student = Student(name=name, email=email, birthdat=birthdat, age=age)
    
    student.save()
    return redirect('/student/')
    
def delete(request, pk):
    student = Student.objects.get(pk=pk)
    student.delete()
    return redirect('/student/')

def edit(request, pk):
    student = Student.objects.get(pk=pk)
    return render(request, 'student/edit.html', {'student':student})

def update(request, pk):
    student = Student.objects.get(pk=pk)
    student.name = request.POST.get('name')
    student.email = request.POST.get('email')
    student.birthdat = request.POST.get('birthdat')
    student.age = request.POST.get('age')
    student.save()
    return redirect('/student/')

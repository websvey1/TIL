import sys

sys.stdin = open("problem_1", "r")
T = int(input())
for tc in 
